from flask import Flask, request, render_template 
import pickle
import os

app = Flask(__name__)

# Load your trained model
script_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(script_dir, 'model_1.pkl')

# Encoding mappings
encoding_mappings = {
    'type of meal': {'Meal Plan 1': 0, 'Meal Plan 2': 1, 'Meal Plan 3': 2, 'Not Selected': 3},
    'room type': {'Room_Type 1': 0, 'Room_Type 2': 1, 'Room_Type 3': 2, 'Room_Type 4': 3, 'Room_Type 5': 4, 'Room_Type 6': 5, 'Room_Type 7': 6}
}

def encode_input(user_input, encoding_mappings):
    encoded_input = {}
    for col, val in user_input.items():
        if col in encoding_mappings:
            encoded_input[col] = encoding_mappings[col].get(val, -1)  # Use -1 for unknown categories
        else:
            encoded_input[col] = val  # For non-categorical columns
    return encoded_input

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user input
    user_input = {
        'number of week nights': int(request.form['number_of_week_nights']),
        'type of meal': request.form['type_of_meal'],
        'room type': request.form['room_type'],
        'lead time': int(request.form['lead_time']),
        'average price': float(request.form['average_price'])
    }

    # Encode user input
    encoded_input = encode_input(user_input, encoding_mappings)

    # Convert to feature array
    features = [[
        encoded_input['number of week nights'],
        encoded_input['type of meal'],
        encoded_input['room type'],
        encoded_input['lead time'],
        encoded_input['average price']
    ]]

    # Make a prediction
    prediction = model_1.predict(features)[0]

    # Map the prediction to a human-readable label (if necessary)
    prediction_text = f'Predicted Booking Status: {prediction}'

    return render_template('index.html', prediction_text=prediction_text)

if __name__ == '__main__':
    app.run(debug=True)
