from flask import Flask, render_template , request
import joblib 
import numpy as np
import pickle


model=joblib.load('my_model_rf.pkl')

app = Flask(__name__)

@app.route('/',methods=['GET'])
def hello_word():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])

def predict():
    data1=request.form['numAdults']
    data2=request.form["numChildren"]
    data3=request.form["numWeekendNights"]
    data4=request.form["numWeekNights"]
    data5=request.form["mealType"]
    data8=request.form["carParkingSpace"]
    data6=request.form["roomType"]
    data7=request.form["leadTime"]
    data9=request.form["repeated"]
    data10=request.form["pc"]
    data11=request.form["pnotc"]
    data12=request.form["avgPrice"]
    data13=request.form["specialRequests"]
    data14=1
    data15=1
    data16=1

    arr=np.array([[data1,data2,data3,data4,data5,data8,data6,data7,data9,data10,data11,data12,data13]])
    pred=model.predict(arr)
    return render_template('after.html',data=pred)
    


if __name__ == '__main__':
    app.run(port=3000,debug=True)