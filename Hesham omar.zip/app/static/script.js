function setMarketSegment(value) {
    document.getElementById("market_segment_type").value = value;
}
