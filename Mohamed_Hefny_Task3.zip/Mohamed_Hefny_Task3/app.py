import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import os

# Create flask app
flask_app = Flask(__name__)
# Get the directory of the current script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the full path to the model file
model_path = os.path.join(current_dir, 'random_forest_model.pkl')

# Load the trained model
with open(model_path, 'rb') as file:
    model = pickle.load(file)

@flask_app.route("/")
def Home():
    return render_template("index.html")

@flask_app.route("/predict", methods = ["POST"])
def predict():
    float_features = [float(x) for x in request.form.values()]
    features = [np.array(float_features)]
    prediction = model.predict(features)

    prediction_text = f"The booking status is: {'Canceled' if prediction == 1 else 'Not Canceled'}"

    return render_template(prediction_text)

if __name__ == "__main__":
    flask_app.run(debug=True)

