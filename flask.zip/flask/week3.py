# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 22:05:58 2024

@author: USER
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 04:10:53 2024

@author: USER
"""

import optuna
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
import pandas as pd
from sklearn.feature_selection import SelectPercentile, chi2
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import joblib
from sklearn.metrics import f1_score

# قراءة البيانات
data = pd.read_csv(r"C:\Users\USER\Downloads\first inten project.csv")

# فحص القيم الفارغة
null_value = data.isnull().sum()
print(null_value)
print("------------------------------------------------------------------------")
print(data.dtypes)
print("------------------------------------------------------------------------")

# تنظيف البيانات
data_c = data.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
print("\nData after cleaning:\n", data_c)
print("------------------------------------------------------------------------")

# معالجة القيم الشاذة
for column in data.columns:
    if data[column].dtype in ['int64', 'float64']:
        Q1 = data[column].quantile(0.25)
        Q3 = data[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        mean_value = data[column].mean()
        data[column] = data[column].apply(lambda x: mean_value if x < lower_bound or x > upper_bound else x)

print("Data after replacing outliers with mean:")
print(data)
print("------------------------------------------------------------------------")

# حذف الأعمدة غير الضرورية
data.drop(columns=['Booking_ID', 'date of reservation'], inplace=True)

# تحويل الأعمدة الفئوية إلى أعمدة رقمية
categorical_cols = data.select_dtypes(include=['object']).columns
data_encoded = pd.get_dummies(data, columns=categorical_cols, drop_first=True)

# فصل المتغيرات المستقلة والمتغير التابع
X = data_encoded.drop(columns=['booking status_Not_Canceled'])
y = data_encoded['booking status_Not_Canceled']

# تقسيم البيانات إلى مجموعة تدريب ومجموعة اختبار
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# اختيار الميزات
Featureselection = SelectPercentile(score_func=chi2, percentile=20)
X_train_selected = Featureselection.fit_transform(X_train, y_train)
X_test_selected = Featureselection.transform(X_test)

# طباعة الميزات المختارة
selected_indices = Featureselection.get_support(indices=True)
selected_features = X.columns[selected_indices]
print("Selected Features:")
for feature in selected_features:
    print(feature)
print("------------------------------------------------------------------------")

# مقياس الميزات
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_selected)
X_test_scaled = scaler.transform(X_test_selected)

# تخفيض الأبعاد باستخدام PCA
pca = PCA(n_components=2)  # تحديد عدد المكونات الرئيسية
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

# دالة الهدف لتحسين النموذج باستخدام Optuna
def objective(trial):
    n_estimators = trial.suggest_int('n_estimators', 100, 300)
    max_depth = trial.suggest_categorical('max_depth', [None, 10, 20, 30])
    min_samples_split = trial.suggest_int('min_samples_split', 2, 10)
    
    model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=min_samples_split
    )
    
    score = cross_val_score(model, X_train_selected, y_train, cv=3, n_jobs=-1)
    accuracy = score.mean()
    return accuracy

# إنشاء دراسة Optuna لتحسين النموذج
study = optuna.create_study(direction='maximize')
study.optimize(objective, n_trials=10)

print("Best Parameters:", study.best_params)
print("Best Score:", study.best_value)

# تدريب النموذج النهائي باستخدام أفضل المعلمات
best_model = RandomForestClassifier(
    n_estimators=study.best_params['n_estimators'],
    max_depth=study.best_params['max_depth'],
    min_samples_split=study.best_params['min_samples_split']
)
best_model.fit(X_train_selected, y_train)

y_pred = best_model.predict(X_test_selected)
f1 = f1_score(y_test, y_pred)
print("F1 Score:", f1)
joblib.dump(best_model, 'best_model.joblib')
joblib.dump(scaler, 'scaler.joblib')
print("Model and scaler saved as best_model.joblib and scaler.joblib respectively")
