# Hotel-Reservations
This dataset is a part of an internship project where I am supposed to work on a machine learning dataset, perform EDA, train,and fine tune a model
