import joblib
import pickle
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from flask import Flask, request, render_template

app = Flask(__name__)

# Load the scaler and model once
sc = StandardScaler()
loaded_model = joblib.load('model_Kendall.pkl')

@app.route('/')
def home():
    return render_template('Task_3_interface.html')

def ValuePredictor(to_predict_list, to_predict_names):
    # Convert to 2D list with one row
    to_predict = pd.DataFrame([to_predict_list], columns=to_predict_names)
    print(to_predict)
    to_predict = sc.fit_transform(to_predict)
    to_predict = pd.DataFrame(to_predict)
    result = loaded_model.predict(to_predict)
    return result[0]

@app.route('/result', methods=['POST'])
def result():
    if request.method == 'POST':
        to_predict_list = request.form.to_dict()
        to_predict_names = list(to_predict_list.keys())
        to_predict_list = list(to_predict_list.values())
        to_predict_list = list(map(int, to_predict_list))
        result = ValuePredictor(to_predict_list, to_predict_names)
        print("results: ", int(result))
        if int(result) == 1:
            prediction = 'Not Cancelled'
        else:
            prediction = 'Cancelled'
        return render_template("Task_3_results.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
