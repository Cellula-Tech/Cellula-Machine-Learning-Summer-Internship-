# Run the app
```bash
python -m flask --app app.py run
```