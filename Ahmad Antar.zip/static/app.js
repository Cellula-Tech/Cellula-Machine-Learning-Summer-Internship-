$(document).on('submit', '#prediction-form', function (e) {
    e.preventDefault();

    $('#results').empty();

    // Serialize form data
    var formData = $(this).serialize();

    // Send AJAX request
    $.ajax({
        type: 'POST',
        url: '/predict',
        data: formData,
        success: function(response) { 
            let data = response.data;
            data.forEach(row => {
                $('#results').append(`
                    <p class="mb-1 ${row.prediction ? 'text-success' : 'text-danger'}">${row.model_name}: ${row.prediction}</p>
                `)
            });
        },
        error: function(xhr, status, error) {
            console.error('Error:', status, error);
            
            alert('Prediction failed: ' + error);
        }
    });
});
