from datetime import datetime
import os
import pickle
import joblib
from flask import Flask, jsonify, render_template, request
app = Flask(__name__)


data_map = {
    # 'meal_type': {
    #     0: 'Not selected',
    #     1: 'Meal plan 1',
    #     2: 'Meal plan 2',
    #     3: 'Meal plan 3'
    # },
    # 'room_type': {
    #     0: 'Room type 1',
    #     1: 'Room type 2',
    #     2: 'Room type 3',
    #     3: 'Room type 4',
    #     4: 'Room type 5',
    #     5: 'Room type 6',
    #     6: 'Room type 7',
    # },
    'market_segment_type': {
        'offline': 0,
        'online': 1,
        'corporate': 2,
        'aviation': 3,
        'complementary': 4,
    },
}

@app.route('/')
def home():
    global data_map

    return render_template('home.html', data_map=data_map)


@app.route('/predict', methods=['POST'])
def predict():
    global data_map

    models_directory = os.path.join(app.root_path, 'static/models')

    form_data = request.form

    # Preprocess data
    date_data = __extract_date_data(form_data.get('reservation_date'))
    input = [
        int(form_data.get('adults_number')),
        int(form_data.get('children_number')),
        int(form_data.get('weekend_nights_number')),
        int(form_data.get('week_nights_number')),
        int(form_data.get('car_parking_space')),
        int(form_data.get('lead_time')),
        int(form_data.get('is_repeated', 0)),
        int(form_data.get('average_price')),
        int(form_data.get('special_requests')),
        int(form_data.get('market_segment_type')) == data_map['market_segment_type']['aviation'],
        int(form_data.get('market_segment_type')) == data_map['market_segment_type']['complementary'],
        int(form_data.get('market_segment_type')) == data_map['market_segment_type']['corporate'],
        int(form_data.get('market_segment_type')) == data_map['market_segment_type']['offline'],
        int(form_data.get('market_segment_type')) == data_map['market_segment_type']['online'],
        date_data['day_of_week'],
        date_data['day_of_month'],
        date_data['week'],
        date_data['month'],
        date_data['year'],
    ]

    # Load the scaler from the file
    with open(os.path.join(models_directory, 'scaler.pkl'), 'rb') as f:
        scaler = pickle.load(f)
    input = scaler.transform([input])

    # Load models and predict
    results = []
    models_file_list = os.listdir(models_directory)
    for filename in [file for file in models_file_list if file.endswith('.pkl') and file.startswith('model_')]:
        filepath = os.path.join(models_directory, filename)
    
        # Load the model from the pickle file
        try:
            with open(filepath, 'rb') as f:
                model = pickle.load(f)
        except Exception as e:
            print('----- ERROR -----')
            print(e)
            continue
        
        results.append({
            'model_name': filename.replace('model_', '').replace('.pkl', ''),
            'prediction': model.predict(input)
        })

    results = [
        {
            'model_name': 'Test 01',
            'prediction': 1
        },
        {
            'model_name': 'Test 02',
            'prediction': 0
        },
    ]

    return jsonify({
        'message': 'Booking status predicted successfully',
        'data': results
    })

def __extract_date_data(date_string):
    date_obj = datetime.strptime(date_string, '%Y-%m-%d')

    return {
        'day_of_week': date_obj.weekday(), # Monday=0, Sunday=6
        'day_of_month': date_obj.day, # 1-31
        'week': int(date_obj.strftime('%V')), # 1-53
        'month': date_obj.month, # 1-12
        'year': date_obj.year 
    }

if __name__ == '__main__':
    app.run(debug=False)