from flask import Flask, render_template, request
import pickle
import numpy as np

with open('model.pkl', 'rb') as file:
    model = pickle.load(file)

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    float_features = [float(x) for x in request.form.values()]
    features = [np.array(float_features)]
    prediction = model.predict(features)
    prediction_text = f"The booking status is: {'Canceled' if prediction == 1 else 'Not Canceled'}"
    return render_template("index.html", prediction_text=prediction_text)


if __name__ == "__main__":
    app.run(debug=True)
