from flask import Flask, request, jsonify, render_template
import joblib
import pandas as pd

app = Flask(__name__)

# Load the model
model = joblib.load('random_forest_model.joblib')

# List of selected features
selected_features = [
    'lead_time',
    'average_price',
    'special_requests',
    'reservation_day',
    'Month',
    'number_of_week_nights',
    'type_of_meal_Meal Plan 2',
    'type_of_meal_Not Selected',
    'market_segment_type_Offline',
    'market_segment_type_Online',
    'market_segment_type_Corporate',
    'room_type_Room_Type 6',
]

# Helper function to validate input data
def validate_input(data):
    '''
    Validate input data.
    '''
    # Ensure data is a dictionary with keys matching selected features
    if not isinstance(data, dict):
        raise ValueError("Input data must be a dictionary.")
    
    for feature in selected_features:
        if feature not in data:
            raise ValueError(f"Missing feature: {feature}")
    
    return True

@app.route('/predict', methods=['POST'])
def predict():
    '''
    Endpoint to predict whether a booking will be canceled or not.
    '''
    try:
        data = request.json
        
        # Validate input data
        validate_input(data)
        
        # Create DataFrame from input data
        df = pd.DataFrame([data])
        
        # Perform prediction
        prediction = model.predict(df[selected_features])  # Ensure only selected features are used
        
        # Prepare response based on prediction
        if prediction[0] == 1:
            result = "Canceled"
        else:
            result = "Not Canceled"
        
        response = {
            'success': True,
            'prediction': prediction.tolist()[0],
            'result': result
        }
        
        return jsonify(response)
    
    except ValueError as ve:
        return jsonify({'success': False, 'error': str(ve)}), 400
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/', methods=['GET', 'POST'])
def index():
    '''
    Home page.
    '''
    if request.method == 'POST':
        try:
            # Extract data from form
            data = {}
            for feature in selected_features:
                data[feature] = float(request.form.get(feature, 0.0))
            
            # Validate input data
            validate_input(data)
            
            # Create DataFrame from input data
            df = pd.DataFrame([data])
            
            # Perform prediction
            prediction = model.predict(df[selected_features])  # Ensure only selected features are used
            
            # Prepare response based on prediction
            if prediction[0] == 1:
                result = "Canceled"
            else:
                result = "Not Canceled"
            
            response = {
                'success': True,
                'prediction': prediction.tolist()[0],
                'result': result
            }
            
            return render_template('index.html', response=response, features=selected_features)
        
        except ValueError as ve:
            error_message = f"Error: {str(ve)}"
            return render_template('index.html', error_message=error_message, features=selected_features)
        
        except Exception as e:
            error_message = f"Error: {str(e)}"
            return render_template('index.html', error_message=error_message, features=selected_features)
    
    # Render the initial form
    return render_template('index.html', features=selected_features)

if __name__ == '__main__':
    app.run(debug=True)
